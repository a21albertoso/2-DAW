1#!/bin/bash
chgrp -R 1233200513 www
chmod go+rx www -R

chgrp -R 1233200513 dump
chmod go+rx dump -R

chgrp -R 1233200513 conf
chmod go+rx conf -R

