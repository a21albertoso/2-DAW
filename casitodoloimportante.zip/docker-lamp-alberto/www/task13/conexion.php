<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
require "Operations.php";
try{
    $conn = new Operations();

}catch(PDOException){
    echo "Connection failed" . $erro->getMessage();
}

try{
    /*echo "Aqui";
        $date = date("Y-m-d-h-i-s");
        $usuario= new MyGuests("Miguel","Seoane","correo@iesanclemente.net",$date);
        $numberOfRows=$oper->addMyGuest($usuario);
        if ($numberOfRows==1) {
            echo "New guest added to database";
        }*/
    $retGuest = $conn->getMyGuest(1);
    echo $retGuest;
    $all=$conn->getAllGuest();
    foreach($all as $user){
        echo "<br> -New user: $user";
    }
}catch (PDOException $erro){
        echo "Error: " . $erro->getMessage();
    }

?>

</body>
</html>


