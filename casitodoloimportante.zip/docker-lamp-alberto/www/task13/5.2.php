<?php
class Student{
    private  $id;
    private  $dni;
    private  $name;
    private $surname;
    private  $age;

    /*function __construct($firstName,$lastName,$email,$reg_date){
        $this->firstName=$firstName;
        $this->lastName=$lastName;
        $this->email=$email;
        $this->reg_date=$reg_date;
    }*/

    function get_dni(){
        return $this->dni;
    }
    function set_dni($dni){
        $this->dni=$dni;
    }
    function get_name(){
        return $this->name;
    }
    function set_name($name){
        $this->name=$name;
    }
    function get_id(){
        return $this->id;
    }
    function set_id($id){
        $this->id=$id;
    }
    function get_surname(){
        return $this->surname;
    }
    function set_surname($surname){
        $this->surname=$surname;
    }
    function get_age(){
        return $this->age;
    }
    function set_age($age){
        $this->age=$age;
    }
    function __toString(){
        $cadea = "<br>ID: $this->id <br>First Name: $this->name";
        $cadea.="<br>Surname: $this->surname <br>Age: $this->age";
        $cadea.="<br>DNI: $this->dni";
        return $cadea;
    }
}

class Operations {
    private $conn;
    function __construct(){
        $this->openConnection();
    }
    function openConnection(){
        $servername = "db";
        $username = "root";
        $password = "test";
        $dbName = "student";
        $this->conn = new PDO("mysql:host=$servername;dbname=$dbName", $username, $password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);   
    }
    function closeConnection(){
        $this->conn=null;
    }
    function addStudent($student){
        $stmt = $this->conn->prepare("insert into student (dni, name, surname, age) VALUES (?, ?, ?, ?)");
        $dni= $student->get_dni();
        $name=$student->get_name();
        $surname=$student->get_surname();
        $age=$student->get_age();
        $stmt->execute([$dni,$name,$surname,$age]);
        $numberOfModifiedRows=$stmt->rowCount();
        return $numberOfModifiedRows;
    }

    function deleteStudent($delID){
        $delete=$this->conn->prepare("delete from student where id=?");
        $delete->execute([$delID]);
    }

    function updateStudent($newStudent){
        $stmt = $this->conn->prepare("update into student (dni, name, surname, age) VALUES (?, ?, ?, ?)");
        $dni= $guest->get_dni();
        $name=$guest->get_name();
        $surname=$guest->get_surname();
        $age=$guest->get_age();
        $stmt->execute([$dni,$name,$surname,$age]);
        $numberOfModifiedRows=$stmt->rowCount();
        return $numberOfModifiedRows;
    }

    function  getStudent($id){
        $sqlString="select id, dni, name, surname, age from student where id=?";
        $consulta=$this->conn->prepare($sqlString);
        $consulta ->execute([$id]);
        $student=$consulta->fetchObject('student');
        return $student;
    }
     function selectAllStudents() { 
        $statement="select id, dni, name, surname, age from student ";
        $consulta=$this->conn->prepare($statement);
        $consulta->execute();
        $allStudents=array();

        while ($student=$consulta->fetchObject('student')) {
            $allStudents[]=$student;
        }
        
        return $allStudents;
    }
}

?>