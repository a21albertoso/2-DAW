<?php
class Car {
  
    public string $color;
    public int $wheels;

}
?>
