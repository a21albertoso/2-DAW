<?php

interface Mostrar{
    public function mostrar($string);
}

class Mostrado implements Mostrar{

function mostrar($string){
    echo $string;
}

}

$obj = new Mostrado();
$obj->mostrar("mejor pájarito en mano que ciento volando");


/* abstract class */



abstract class Mostrar2{
    public abstract function mostrar($string);
}

class Mostrado2 extends Mostrar2{

function mostrar($string){
    echo $string;
}

}

$obj2 = new Mostrado2();
$obj2->mostrar("<br><br>mejor pájarito en mano que ciento volando");


// trait



trait Mostrar3{
    function mostrar($string){
        echo $string;
    }
}

class Mostrado3{
    use Mostrar3;
}



$obj2 = new Mostrado3();
$obj2->mostrar("<br><br>mejor pájarito en mano que ciento volando");



?>

