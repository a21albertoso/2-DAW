<?php
	session_start();
	echo "La variable count vale: " . $_SESSION['count']; 

