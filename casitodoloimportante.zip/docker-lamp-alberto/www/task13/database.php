<?php

class users{
    //variables, getters and setters of user.
    private $ID;
    private $username;
    private $password;


    function getID(){
        return $this->ID;
    }

    function setID($ID){
        $this->ID=$ID;
    }

    function getUsername(){
        return $this->username;
    }

    function setUsername($username){
        $this->username=$username;
    }

    function getPassword(){
        return $this->password;
    }

    function setPassword($password){
        $this->password=$password;
    }

    

}
class messages extends users{
    //variables, getters and setters of messages (extended of users).
    private $messageID;
    private $messageText;
    private $userID;

    function get_messageID(){
        return $this->messageID;
    }

    function set_messageID($messageID){
        $this->messageID=$messageID;
    }

    function get_messageText(){
        return $this->messageText;
    }

    function set_messageText($messageText){
        $this->messageText=$messageText;
    }

    function getUserID(){
        return $this->userID;
    }

    function setUserID($userID){
        $this->userID=$userID;
    }

    function __toString(){
       return $this->messageID . $this->messageText . $this->userID;

    }

}

class Operations{
    //creation of connection.
    private $conn;
    function __construct(){
        $this->openConnection();
    }
    //conection with phpMyAdmin database.
    function openConnection(){
        $servername = "db";
        $username = "dbuser";
        $password = "test";
        $dbname = "dbproject";
        $this->conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        function closeConnection(){
            $this->conn=null;
        }
        //add user in the users database
        function addUser($user){
            $stmt = $this->conn->prepare("insert into users (username, password) VALUES (?, ?)");
            $username = $user->getUsername();
            $password = $user->getPassword();
            $stmt->execute([$username,$password]);
            $numberOfModifiedRows=$stmt->rowCount();
            return $numberOfModifiedRows;
        }

        //select all the users to print it in table
        function selectAllUsers(){
            $statement="select ID, username, password from users";
            $consult=$this->conn->prepare($statement);
            $consult->execute();
            $allUsers=array();

            while($message=$consult->fetchObject('users')){
                $allUsers[]=$message;
            }
            return $allUsers;
        }
        //add a message in the respective table.
        function addMessage($message,$userID){
            $stmt = $this->conn->prepare("insert into messages (messageText, userID) VALUES (?, ?)");
            $messageText = $message->get_messageText();
            $stmt->execute([$messageText, $userID]);
            $numberOfModifiedRows=$stmt->rowCount();
            return $numberOfModifiedRows;
        }
        
        function modifyMessage($newMessage, $messageID){
            $stmt = $this->conn->prepare("update messages set messageText='$newMessage' where messageID='$messageID'");
            $stmt->execute([$newMessage,$messageID]);
        }
        //rewriting of the message to can edit it in database.
        function getMessage($messageID){
            $sqlString="select messageText FROM messages where messageID=?";
            $consult=$this->conn->prepare($sqlString);
            $consult->execute([$messageID]);
            $messages=$consult->fetchObject('messages');
            return $messages;
        }
        // select all messages to print it.
        function selectAllMessages($ID){
            $statement="select messageID, messageText FROM messages WHERE userID = ? ";
            $consult=$this->conn->prepare($statement);
            $consult->execute([$ID]);
            $allMessages=array();

            while ($messages=$consult->fetchObject('messages')) {
                $allMessages[]=$messages;
            }
            return $allMessages;
        }
}



?>