<?
class MyGuests{
    private $id;
    private $firstName;
    private $lastName;
    private $email;
    private $reg_date;

    /*function __construct($firstName,$lastName,$email,$reg_date){
        $this->firstName=$firstName;
        $this->lastName=$lastName;
        $this->email=$email;
        $this->reg_date=$reg_date;
    }*/

    function get_firstName(){
        return $this->firstName;
    }
    function set_firstName($firstName){
        $this->firstName=$firstName;
    }
    function get_lastName(){
        return $this->lastName;
    }
    function set_lastName($lastName){
        $this->lastName=$lastName;
    }
    function get_id(){
        return $this->id;
    }
    function set_id($id){
        $this->id=$id;
    }
    function get_email(){
        return $this->email;
    }
    function set_email($email){
        $this->email=$email;
    }
    function get_reg_date(){
        return $this->reg_date;
    }
    function set_reg_date($reg_date){
        $this->reg_date=$reg_date;
    }
    function __toString(){
        $cadea = "<br>ID: $this->id <br>First Name: $this->firstName";
        $cadea.="<br>Last Name: $this->lastName <br>Email: $this->email";
        $cadea.="<br>Reg date: $this->reg_date";
        return $cadea;
    }
}
class Operations extends MyGuests{
    private $conn;
    function __construct(){
        $this->openConnection();
    }
    function openConnection(){
        $servername = "db";
        $username = "root";
        $password = "test";
        $dbName = "dbname";
        $this->conn = new PDO("mysql:host=$servername;dbname=$dbName", $username, $password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);   
    }
    function closeConnection(){
        $this->conn=null;
    }

    function addMyGuest($guest){
        $stmt = $this->conn->prepare("insert into MyGuests (firstname, lastname, email, reg_date) VALUES (?, ?, ?, ?)");
        $firstname= $guest->get_firstName();
        $lastname=$guest->get_lastName();
        $correo=$guest->get_email();
        $fecha=$guest->get_reg_date();
        $stmt->execute([$firstname,$lastname,$correo,$fecha]);
        $numberOfModifiedRows=$stmt->rowCount();
        return $numberOfModifiedRows;
    }
    function updateMyGuest($newGuest){
        $stmt = $this->conn->prepare("update into MyGuests (firstname, lastname, email, reg_date) VALUES (?, ?, ?, ?)");
        $firstname= $guest->get_firstName();
        $lastname=$guest->get_lastName();
        $correo=$guest->get_email();
        $fecha=$guest->get_reg_date();
        $stmt->execute([$firstname,$lastname,$correo,$fecha]);
        $numberOfModifiedRows=$stmt->rowCount();
        return $numberOfModifiedRows;
    }
    
    function deleteMyGuest($delID){
        $delete=$this->conn->prepare("delete from MyGuests where id=?");
        $delete->execute([$delID]);
    }
    function  getMyGuest($id){
        $sqlString="select id, firstName, lastName, email, reg_date from MyGuests where id=?";
        $consulta=$this->conn->prepare($sqlString);
        $consulta ->execute([$id]);
        $myGuest=$consulta->fetchObject('MyGuests');
        return $myGuest;
    }
     function selectAllMyGuest() { 
        $statement="select id , firstName ,lastName ,email, reg_date from MyGuests";
        $consulta=$this->conn->prepare($statement);
        $consulta->execute();
        $allGuests=array();

        while ($myGuest=$consulta->fetchObject('MyGuests')) {
            $allGuests[]=$myGuest;
        }
        
        return $allGuests;
    }
}
?>