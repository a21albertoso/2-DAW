<?php

$obj = new class(){
    private int $number=5;



    public function factorial(){
        $factorial = 1;
         for($x = 1;$x <= $this->number; $x++){
            $factorial = $factorial * $x;
         }
         return $factorial;
    }
};

$resultado = $obj->factorial();

echo $resultado;
?>