<?php

class numbers{

private $number1;
private $number2;

function set_number1($number1) {
    $this->number1 = $number1;
}

function get_number1() {
    return $this->number1;
}

function set_number2($number2) {
    $this->number2 = $number2;
}

function get_number2(){
    return $this->number2
}

}



?>