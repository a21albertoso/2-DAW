<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QUERING DATA FROM DATABASE</title>
</head>
<body>
    <h1>QUERING DATA FROM DATABASE</h1>
    <?php
    require "Operations.php";
    try {
        $oper = new Operations();

    } catch (PDOException $erro) {
        echo "Connection Failed: ". $erro->getMessage();
    }
    try {
        /*echo "Aqui";
        $date = date("Y-m-d-h-i-s");
        $usuario= new MyGuests("Miguel","Seoane","correo@iesanclemente.net",$date);
        $numberOfRows=$oper->addMyGuest($usuario);
        if ($numberOfRows==1) {
            echo "New guest added to database";
        }*/
        $select=$oper->getMyGuest(72);
        echo $select;
        $all= $oper->selectAllMyGuest();
             foreach( $all as $user ){
                echo "<br><br>-Novo usuario: $user";
             }
    }
    catch(Exception $erro){
        echo "Erro: ".$erro->getMessage();
    }

    
    ?>
</body>
</html>