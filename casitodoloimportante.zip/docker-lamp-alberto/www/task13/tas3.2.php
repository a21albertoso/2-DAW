<?php

class Numbers{
    private static int $constante = 4;
    private int $numero;

    public function __construct($numero){
        $this->numero = $numero;
    }

    public function getNumero(){
        return $this->numero;
    }

    public function setNumero($numero){
        $this->numero = $numero;
    }

    static function multiplyconstant($x){
        return $x * self::$constante;
    }

    function multiplynumber($x){
        return $x * $this->numero;
    }

}

$resultado = new Numbers(10);
echo $resultado->multiplynumber(9);
echo "<br>";
echo Numbers::multiplyconstant(5);

?>