<!DOCTYPE html>

<html>
<title>Multidimensional Arrays</title>



<body>
    <h2>Multidimensional arrays.</h2>
    <?php
    $arrayTotal = array(
        "Jhon" =>  array(
            "email" => "jhon@demo.com",
            "website" => "www.jhon.com",
            "age" => "22",
            "Password" => "pass"
        ),
        "Anna" => array(
            "email" => "anna@demo.com",
            "website" => "www.anna.com",
            "age" => "20",
            "Password" => "pass"
        ),
        "Peter" => array(
            "email" => "peter@demo.com",
            "website" => "www.jhon.com",
            "age" => "43",
            "Password" => "pass"
        ),
        "Max" => array(
            "email" => "max@demo.com",
            "website" => "www.max.com",
            "age" => "33",
            "Password" => "pass"
        )
    );
    echo "<ul>";
    foreach ($arrayTotal as $nome => $arrai) {
        echo "<br><li>" . $nome . "</li>";
        foreach ($arrai as $titulo => $valor) {
            echo "<li>" . $titulo . " : " . $valor . "</li>";
        }
    }
    echo "</ul>";
    ?>
</body>

</html>