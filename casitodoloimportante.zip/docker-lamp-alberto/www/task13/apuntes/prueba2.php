<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        function potencia(int $num = 4, int $fun = 2){
            $resultado = pow($num, $fun);
            return $resultado;
        }

        $num = 4;
        $fun = 2;

        if($fun <= 0){
            echo -1;
        }else{
            $resultado = potencia($num, $fun);
            echo $resultado;
        }


    ?>
</body>
</html>