<!DOCTYPE html>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  border-right:1px solid #bbb;
}

li:last-child {
  border-right: none;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #04AA6D;
}
</style>
</head>
<body>

<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="cv.php">Form</a></li>
  <li><a class="active" href="#contact">DNI Check</a></li>
  <li style="float:right"><a href="#about">About</a></li>
</ul>



<?php
$dni = "";

if(isset($_REQUEST["submit"])){
    if(empty($_POST["fdni"])){
        echo "type your DNI: ";
    }else{
        $dni = ($_POST["fdni"]);
        dni($dni);
    }
}

function dni($dni){
    $letra = substr($dni, -1);
    $numeros = substr($dni, 0, -1);
    if (substr("TRWAGMYFPDXBNJZSQVHLCKE", $numeros%23, 1) == $letra && strlen($letra) == 1 && strlen ($numeros) == 8 ){
    echo "Valid DNI";
    
    }else{
    echo "Invalid DNI";
    }
    return $dni;
    }
    
    



if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  if (empty($_POST["fdni"])) {
    echo "DNI is empty, have spaces or incorrect characters.<br>";
  } else { 
    $dni = $_POST['fdni'];
  }
}
if(isset($_REQUEST["reset"])) {
  $name=$pass=$dni="";
} ?>

<div id="news">
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ; ?>" method="post" enctype="multipart/form-data">
        <h1>DNI Check</h1>
        <label>DNI:</label>
        <input type="text" name="fdni" value=<?php echo $dni; ?>><br><br>
        <input type="submit" value="submit" name="submit">
        <input type="submit" value="reset" name="reset">
    </form>
</div>

</body>
</html>