<DOCTYPE html>

    <head>
    </head>
    <body>

        <h1>Máquina Expendedora</h1>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            Name: <input type="text" name="fname">
            <br>
            Amount: <input type="number" name="fnumber">
            <input type="submit">
        </form>

        </form>
        <?php
        $bebida = "";
        $cantidad = 0;
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // collect value of input field
            $bebida = $_POST['fname'];
            if (empty($bebida)) {
                echo "Name is empty";
            } else {
                $bebida = test_input($_POST["fname"]);
                // check if name only contains letters and whitespace
                if (!preg_match("/^[a-zA-Z-' ]*$/", $bebida)) {
                    echo "Only letters and white space allowed.<br>";
                }
            }
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // collect value of input field
            $cantidad = $_POST['fnumber'];
            if (empty($cantidad)) {
                echo "Name is empty";
            }
        }
        function test_input($data)
        {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        function maquina(string $bebida, int $cantidad)
        {
            switch ($bebida) {
                case 'Coke':
                    echo "You have asked for " . $cantidad . " bottles of " . $bebida . ". Total price to pay: " . 1 * $cantidad;
                    break;
                case 'Orange':
                    echo "You have asked for " . $cantidad . " bottles of " . $bebida . ". Total price to pay: " . 0.9 * $cantidad;
                    break;
                case 'Apple juice':
                    echo "You have asked for " . $cantidad . " bottles of " . $bebida . ". Total price to pay: " . 1.1 * $cantidad;
                    break;
                case 'Pepsi':
                    echo "You have asked for " . $cantidad . " bottles of " . $bebida . ". Total price to pay: " . 0.8 * $cantidad;
                default:
                    echo "You have to ask for a drink";
                    break;
            }
        }
        $bebidaElegida = maquina($bebida, $cantidad);

        echo "$bebidaElegida";
        ?>
    </body>


    </html>