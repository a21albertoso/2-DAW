<!DOCTYPE html>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  border-right:1px solid #bbb;
}

li:last-child {
  border-right: none;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #04AA6D;
}
</style>
</head>
<body>

<ul>
  <li><a href="index.php">Home</a></li>
  <li><a class="active" href="#news">Form</a></li>
  <li><a href="dni2.php">DNI Check</a></li>
  <li style="float:right"><a href="#about">About</a></li>
</ul>


<?php
$name = "";
$pass = "";

if ($_SERVER["REQUEST_METHOD"]=="POST") {
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if file already exists
if (file_exists($target_file)) {
  $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  echo "Sorry, your file is too large.<br>";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" ) {
  echo "Sorry, only JPG files are allowed.<br>";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.<br>";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.<br>";
  }
}
}
?>


<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  if (empty($_POST["fname"])) {
    echo "Name is empty, have spaces or incorrect characters.<br>";
  } else { 
    $name = $_POST['fname'];
    
  }
}
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  if (empty($_POST["fpass"])) {
    echo "Surame is empty, have spaces or incorrect characters.<br>";
  } else { 
    $pass = $_POST['fpass'];
  }
}
?>

<?php
if(isset($_REQUEST["reset"])) {
  $name=$pass="";
} ?>

<div id="news">
<h1>Form</h1>
<h2>Rellena tu CV</h2>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ; ?>" method="post" enctype="multipart/form-data">
      <label>Name:</label>
        <input type="text" name="fname" value=<?php echo $name ?>><br><br>
        <label>Surnames:</label>
        <input type="text" name="fpass" value=<?php echo $pass ?>><br><br>
        <input type="file" name="fileToUpload" id="fileToUpload">
        <br><br>
        <input type="checkbox">
        <label>Subscribe me to news.</label><br><br>
        <input type="submit" value="submit" name="submit">
        <input type="submit" value="reset" name="reset">
    </form>
</div>

</body>
</html>
