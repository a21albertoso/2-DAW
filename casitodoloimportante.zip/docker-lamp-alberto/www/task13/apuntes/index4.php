<html>

<head>

    <title>Ejemplo de una web con PHP - aprenderaprogramar.com</title>

</head>

<body>

    <?php
    function tripleCheck(array $numbers)
    {
        $contador = 0;
        for ($x = 0; $x < count($numbers) - 2; $x++) {

            if ($numbers[$x] == $numbers[$x + 1] && $numbers[$x] == $numbers[$x + 2]) {
                $contador = $contador + 1;
            }
        }
        if ($contador > 0) {
            echo "bool(true)";
        } else {
            echo "bool(false)";
        }
        echo "<br>";
    }
    $array1 = array(1, 1, 2, 2, 1);
    $array2 = array(1, 1, 2, 1, 2, 3);
    $array3 = array(1, 1, 1, 2, 2, 2, 1);
    tripleCheck($array1);
    tripleCheck($array2);
    tripleCheck($array3);




    function countries()

    {
        $ceu = array("Italy" => "Rome", "Luxembourg" => "Luxembourg", "Belgium" => "Brussels", "Denmark" => "Copenhagen", "Finland" => "Helsinki", "France" => "Paris", "Slovakia" => "Bratislava", "Slovenia" => "Ljubljana", "Germany" => "Berlin", "Greece" => "Athens", "Ireland" => "Dublin", "Netherlands" => "Amsterdam", "Portugal" => "Lisbon", "Spain" => "Madrid", "Sweden" => "Stockholm", "United Kingdom" => "London", "Cyprus" => "Nicosia", "Lithuania" => "Vilnius", "Czech Republic" => "Prague", "Estonia" => "Tallin", "Hungary" => "Budapest", "Latvia" => "Riga", "Malta" => "Valetta", "Austria" => "Vienna", "Poland" => "Warsaw");
        echo "The capital of Netherlands is " . $ceu["Netherlands"] . ".";
        echo "<br>";
        echo "The capital of Greece is " . $ceu["Greece"] . ".";
        echo "<br>";
        echo "The capital of Germany is " . $ceu["Germany"] . ".";
    }
    countries();
    ?>



</body>

</html>