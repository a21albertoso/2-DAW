<html>
    <head>
        <title>DWCS</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    </head>
 
       



<body>
    <?php
    $array = range(0, 29);
    foreach ($array as &$range) {
        $range = rand(0, 20);
    }
    print_r($array);
    echo "<br>"
    ?>
    <?php
    $array = array("Batman", "Superman", "Krusty", "Bob", "Mel", "Barney");
    print_r($array);
    $array = array_diff($array, array("Barney"));
    $posicion = array_search("Superman", $array);
    echo "<br>Superman is in the position: " . $posicion . "<br>";
    $arrray = array_push($array, "Carl", "Lenny", "Burns", "Lisa");
    print_r($array);
    echo "<br>";

    sort($array);
    foreach ($array as $key => $val) {
        echo $key ."=" .$val;
    }

    unset($array[4] , $array[5],$array[6]); 
    print_r($array);
    echo "<br>";
    array_unshift($array,"Manzana","Melón","Sandía");
    print_r($array);

    $micopia = array($array[3] ,$array[4] ,$array[5]);
    echo "<br>";
    print_r($micopia);
    echo "<br>";
    array_push($array,"Pera");
    print_r($array);

    $concat = array_merge($array,$micopia);
    echo "<br>";
    print_r($concat);
    ?>
</body>
</html>