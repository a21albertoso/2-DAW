<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        function factorial($num){
            $factorial = 1;
            for($x = $num; $x >= 1 ; $x--){
                $factorial = $factorial * $x;
            }return $factorial;
        }

        $num = 4;
        if($num <= 0){
            echo "-1";
        }else{
            echo factorial($num);
            
        }

    ?>
</body>
</html>