<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    function tripleCheck(array $numbers){
        $contador = 0;
        for($x = 0; $x < sizeof($numbers) - 2; $x++){
            if ($numbers[$x] == $numbers[$x + 1] && $numbers[$x] == $numbers[$x + 2]){
                $contador = $contador + 1;

                
            }
        }
        if($contador > 0){
            echo "true";
        }else{
            echo "false";
        }
    }


    $array1 = array ( 1, 1, 2, 2, 1 );
    $array2 = array ( 1, 1, 2, 2, 1 );
    $array3 = array ( 1, 1, 1, 2, 2, 1 );
    tripleCheck($array1);
    tripleCheck($array2);
    tripleCheck($array3);


    


    ?>
</body>
</html>