<!DOCTYPE HTML>

<head>
	<title></title>
</head>

<body>
	<h1>Factorial</h1>
	<?php



	function potencia(int $num, int $potencia)
	{
		$resultado = pow($num, $potencia);
		return $resultado;
	}

	$num = 4;
	$potencia = 2;
	if ($num <= 0) {
		echo "-1";
	}
	if ($num >= 0) {
		$resultado = potencia($num, $potencia);
		echo $resultado;
	}
	?>
</body>

</html>