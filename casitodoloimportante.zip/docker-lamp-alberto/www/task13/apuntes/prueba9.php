<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label>Bebida</label>
        <input type="text" name="fname">
        <label>Número</label>
        <input type="number" name="fdrink">
        <input type="submit">
</form>

        <?php
        $bebida = "";
        $drink = 0; 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $bebida = $_POST['fname'];
  if (empty($bebida)) {
    echo "Name is empty";
  } else {
    $bebida = test_input($_POST['fname']);
    if (!preg_match("/^[a-zA-Z-' ]*$/" , $bebida)){
        echo "Only leters allowed. <br>";
    }
  }
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $drink = $_POST['fdrink'];
  if (empty($drink)) {
    echo "Drink is empty <br>";
  }
}

  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

  function maquina(string $bebida, int $drink){
    switch ($bebida) {
        case 'Coke':
          echo "you asked for " . $drink . " " . $bebida . "they might be " . $drink;
          break;
        case 'Pepsi':
            echo "you asked for " . $drink . " " . $bebida . "they might be " . 0.8 * $drink;
          break;
        case 'Orange':
            echo "you asked for " . $drink . " " . $bebida . "they might be " . 0.9 * $drink;
          break;
        case 'Juice':
          echo "you asked for " . $drink . " " . $bebida . "they might be " . 1.10 * $drink;
          break;
        
      }
  }
$select = maquina($bebida, $drink);

echo $select;
?>
</body>
</html>