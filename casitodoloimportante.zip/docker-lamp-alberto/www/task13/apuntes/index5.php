<!DOCTYPE html>

<html>
<title>Regular Expresions</title>

<body>
    <h2>findString</h2>
    <?php
    function findString($p1, $p2)
    {
        if (preg_match($p1, $p2)) {

            echo "Unha palabra está dentro da outra <br>";
        } else {
            echo "Ningunha palabra está dentro da outra <br>";
        }
    }

    function deleteBlanks($palabra)
    {
        echo preg_replace("/\s/", "", $palabra);
    }

    //Función findString

    $string1 = "/unci/i";
    $string2 = "función";

    findString($string1, $string2);
    ?>
    <h2>deleteBlanks</h2>
    <?php
    // Función 2
    $sentence = "Hello my name is Alberto";
    echo "$sentence: <br>";
    deleteBlanks($sentence);
    ?>
</body>

</html>