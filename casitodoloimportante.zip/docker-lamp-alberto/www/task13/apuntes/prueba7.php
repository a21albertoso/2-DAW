<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $arraytotal = array(
       "Jhon" => array(
        "email" => "john@demo.com", "website" => "www.john.com" , "age" => "22" , "password" => "pass"));

       echo "<ul>";
       foreach($arraytotal as $persona => $arraysimple){
        echo "<br><li>" . $persona . "</li>";
        foreach($arraysimple as $info => $datos){
            echo "<li>" . $info . "=>" . $datos . "</li>"; 
        }
       }
    echo "</ul>"
    ?>
</body>
</html>