<!DOCTYPE HTML>

<head>
	<title></title>
</head>

<body>
	<h1>Factorial</h1>
	<?php



	function Factorial($num)
	{
		$factorial = 1;

		for ($x = $num; $x >= 1; $x--) {
			$factorial = $factorial * $x;
		}
		return $factorial;
	}

	$num = 4;
	if ($num <= 0) {
		echo "-1";
	}
	if ($num >= 0) {
		$resultado = Factorial($num);
		echo $resultado;
	}
	?>
</body>

</html>