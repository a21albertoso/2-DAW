<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $array = range(0, 29);
    foreach($array as $range){
        $range = rand(0, 20);
    }

    print_r($array);
    echo "<br>";

    $personajes = array("Batman", "Superman", "Krusty", "Bob", "Mel", "Barney");
    print_r($personajes); echo "<br>";
    array_pop($personajes);
    print_r($personajes);
    $posicion = array_search("Superman", $personajes);
    echo "<BR>Superman esta en el puesto " . $posicion . "<br>";
    array_push($personajes, "Carl", "Lenny", "Burns", "Lisa");
    print_r($personajes);
    sort($personajes);
    echo "<br>";
    print_r($personajes);
    unset($personajes[3], $personajes[4]);
    print_r($personajes);
    array_unshift($personajes, "Manzana", "Melón", "Sandía");
    $micopia = array($personajes[5], $personajes[6]);
    $definitivo = array_merge($personajes, $micopia);
    echo "<br><br>";
    print_r($definitivo);
    ?>
</body>
</html>