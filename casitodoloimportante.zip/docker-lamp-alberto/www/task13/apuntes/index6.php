<!DOCTYPE html>

<html>
<title>Arrays and Strings</title>



<body>
    <h2>Multidimensional arrays.</h2>
    <?php
    $array = "Tokyo,Japan,Asia;Mexico City,Mexico,America;New York City,USA,America;Mumbai,India,Asia;Seoul,Korea,Asia;Shanghai,China,Asia;Lagos,Nigeria,Africa;Buenos Aires,Argentina,America;Cairo,Egypt,Africa;London,UK,Europe";

    echo "<table>";
    echo "<tr>";
    echo "<th>";
    echo "City";
    echo "</th>";
    echo "<th>";
    echo "Country";
    echo "</th>";
    echo "<th>";
    echo "Continent";
    echo "</th>";
    echo "</tr>";

    $separator = explode(";", $array);
    for ($i = 0; $i < count($separator); $i++) {
        $separator2 = explode(",", $separator[$i]);

        echo "<tr>";
        echo "<td>";
        echo $separator2[0];
        echo "</td>";
        echo "<td>";
        echo $separator2[1];
        echo "</td>";
        echo "<td>";
        echo $separator2[2];
        echo "</td>";
        echo "</tr>";
    }

    echo "</table>";

    ?>
</body>

</html>