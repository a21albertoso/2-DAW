<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $information="Tokyo,Japan,Asia;Mexico City,Mexico,America;New York City,USA,America;Mumbai,India,Asia;Seoul,Korea,Asia;Shanghai,China,Asia;Lagos,Nigeria,Africa;Buenos Aires,Argentina,America;Cairo,Egypt,Africa;London,UK,Europe";
    echo "<table>";
    echo "<tr>";
    echo "<th>";
    echo "City";
    echo "</th>";
    echo "<th>";
    echo "Country";
    echo "</th>";
    echo "<th>";
    echo "Continent";
    echo "</th>";
    echo "</tr>";

    $separator = explode(";" , $information);
    for($x = 0; $x < sizeof($separator); $x++){
        $separator2 = explode("," , $separator[$x]);
    

    echo "<tr>";
    echo "<td>";
    echo $separator2[0];
    echo "</td>";
    echo "<td>";
    echo $separator2[1];
    echo "</td>";
    echo "<td>";
    echo $separator2[2];
    echo "</td>";
    echo "</tr>";

    }

    echo "<table>";

    ?>
</body>
</html>