<!DOCTYPE HTML>

<head>
	<title></title>
</head>

<body>
	<h1>Factorial</h1>
	<?php

	$num = 4;
	$factorial = 1;

	for ($x = $num; $x >= 1; $x--) {
		$factorial = $factorial * $x;
	}

	echo $factorial;

	?>
</body>

</html>