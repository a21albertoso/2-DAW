<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>NOTES:</h1>
<form method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">

<?php

    require "database.php";
    try {
        $oper = new Operations();
    } catch (PDOException $erro) {
        echo "Connection Failed: ". $erro->getMessage();
    }
    
    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $ID = $_GET["id"];

    $messageText="";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_REQUEST["addnote"])){
        $newNote = new messages();
        $newNote->set_messageText($messageText);
        $IDuser = $ID;
        $numberOfRows=$oper->addMessage($newNote,$IDuser);
    }
}

    $all = $oper->selectAllMessages($ID);
    foreach ( $all as $notes){
        echo "<table>
        <tr>
        <td>" . $notes->get_messageText() . "</td>
        <td><a href=index.php?id=".$notes->get_messageID()."&userID=".$ID.">View note</a></td>
        </tr></table>";
    }

    ?>

    <a href="index.php"><input type="submit" value="add" name="addnote"></a>

    <?php
echo "<a href="."users.php>back</a>";
?>

</tr>
</table>
</form>

<style>

table{
    background-color: lightgray;
}

td{
    width: 80px;
    background-color: DAF402;
}

a{
    background-color: black;
    color:white;
    text-decoration: none;
    border: 2px solid grey;
}

a:hover{
    background-color: white;
    color:black;
    text-decoration: none;
    border: 2px solid black;
}

input{
    background-color: black;
    color:white;
    text-decoration: none;
    border: 2px solid grey;
}

input:hover{
    background-color: white;
    color:black;
    text-decoration: none;
    border: 2px solid black;
}

body{
    display: flex;
    align-items: center;
    flex-direction: column;
    background-color: BDB70B;
}

h1{
    background-color: black;
    color: white;
    width: 100%;
    top:0;
    display: flex;
    justify-content: center;
}
</style>
</body>
</html>