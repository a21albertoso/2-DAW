<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form  method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">
<?php

    require "5.2.php";
    try {
        $oper = new Operations();

    } catch (PDOException $erro) {
        echo "Connection Failed: ". $erro->getMessage();
    }
    
    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    $name=$surname=$dni="";
    $age=0;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_REQUEST["modify"])) {
            $newUser=new Student();
            if (empty($_POST["name"])||$_POST["name"]==" ") {
                echo "You must indicate a name";
            }else{
                $name = test_input($_POST["name"]);
                if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
                  $errorNome = "Only letters and white space allowed";
                }
                $newUser->set_name($name);
            }
            if (empty($_POST["age"])||$_POST["age"]==0) {
                echo "You must indicate an age";
            }else{
                $age = test_input($_POST["age"]);
                if (!preg_match("/^[0-9]*$/",$age)) {
                  echo "Only numbers allowed";
                }
                $newUser->set_age($age);

            }
            if (empty($_POST["surname"])||$_POST["surname"]==" ") {
                echo "You must indicate a surname";
            }else{
                $surname = test_input($_POST["surname"]);
                if (!preg_match("/^[a-zA-Z-' ]*$/",$surname)) {
                  $errorNome = "Only letters and white space allowed";
                }
                $newUser->set_surname($surname);

            }

            if (empty($_POST["dni"])||$_POST["dni"]==" ") {
                echo "You must indicate a dni";
            }else{
                $dni = test_input($_POST["dni"]);
                if (!preg_match('/^[0-9]{7,8}[A-Z]/', $dni)) {
                  $errorNome = "Only letters and white space allowed";
                }
                $newUser->set_dni($dni);

            }
            if (empty($_POST["dni"])||$_POST["dni"]==" "&&empty($_POST["surname"])||$_POST["surname"]==" "&&empty($_POST["age"])||$_POST["age"]==0&&empty($_POST["name"])||$_POST["name"]==" ") {
                echo "Non se puido engadir o usuario";
            }else{
                $numberOfRows=$oper->updateStudent($newUser,$_GET["id"]);
                if($numberOfRows==1) {
                    echo "<br>Student Updated";
                }
            }  
        } 
        if (isset($_REQUEST["borrar"])) {
                $delDNI = $_GET["id"];
                $numberOfRows=$oper->deleteStudent($delDNI);
                if($numberOfRows<0) {
                    $message= "Error.<br>The student couldn't been deleted";
                }
            }
        
    }
     
    
    $name=$surname=$dni="";
    $age=0; 
    
    
?>



    <fieldset>
<legend>Delete a student</legend>
        <table>
            <tr>
                <td>
                    <?php 
                    $message="Do you u want to delete the next user?";
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        if (isset($_REQUEST["borrar"])) {
                            $message="Student deleted";
                        }else{
                            $message="Do you u want to delete the next user?";
                        }
                    }
                    echo $message;
                $select=$oper->getStudent($_GET["id"]);
                echo $select;
                
                ?></label></td>
            </tr>
            <tr>
                <td> <input  type="submit" name="borrar" value="Delete"><br></td>
            </tr>
        </table>
    </fieldset>
    <fieldset>
        <legend>Modify a student</legend>
        <table>
        <a>*Introduce the DNI of the student you want modify for the user: </a><br>
        <?php
        $select=$oper->getStudent($_GET["id"]);
        echo $select;
        ?>
        <tr></tr>
        <tr></tr>
        <tr></tr>
            <tr>
                <td><label for="name">Name: </label></td>
                <td><input type="text" name="name" id="1"value=""></td>
                <td><label for="age">Age: </label></td>
                <td><input type="text" name="age" id="3"></td>
            </tr>
            <tr>
                <td><label for="name">Surname: </label></td>
                <td><input type="text" name="surname"  id="2" ></td>
                <td><label for="dni">DNI: </label></td>
                <td><input type="text" name="dni" id="4" ></td>
            </tr>
            <tr>
                <td> <input  type="submit" name="modify" value="Modify"><br></td>
            </tr>
        </table>
    </fieldset>
    <a href="index.php">Menu</a>

</form>
</body>
</html>