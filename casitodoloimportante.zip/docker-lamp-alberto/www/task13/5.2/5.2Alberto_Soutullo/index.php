<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>List of alumns</h1>
    <form  method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">
    <?php

    require "5.2.php";
    try {
        $oper = new Operations();

    } catch (PDOException $erro) {
        echo "Connection Failed: ". $erro->getMessage();
    }
    try {
        /*echo "Aqui";
        $date = date("Y-m-d-h-i-s");
        $usuario= new MyGuests("Miguel","Seoane","correo@iesanclemente.net",$date);
        $numberOfRows=$oper->addMyGuest($usuario);
        if(numberOfRows==1) {
            echo "New guest added to database";
        }*/
        
        $all= $oper->selectAllStudents();
             foreach( $all as $user ){
                echo "<br><br>-Novo usuario: $user";
                echo "<br><a href=modify.php?accion="."borrar&id=".$user->get_id()." >Modify User</a>";

        }
                   
    }
    catch(Exception $erro){
        echo "Erro: ".$erro->getMessage();
    }
    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    $name=$surname=$dni=$surnameError=$dniError=$ageError=$errorNome=$added="";
    $age=0;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_REQUEST["add"])) {
            $newUser=new Student();
            if (empty($_POST["name"])||$_POST["name"]==" ") {
                $errorNome= "You must indicate a name";
            }else{
                $name = test_input($_POST["name"]);
                if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
                  $errorNome = "Only letters and white space allowed";
                }
                $newUser->set_name($name);
            }
            if (empty($_POST["age"])||$_POST["age"]==0) {
                $ageError= "You must indicate an age";
            }else{
                $age = test_input($_POST["age"]);
                if (!preg_match("/^[0-9]*$/",$age)) {
                  $ageError= "Only numbers allowed";
                }
                $newUser->set_age($age);

            }
        
        
            if (empty($_POST["surname"])||$_POST["surname"]==" ") {
                $surnameError= "You must indicate a surname";
            }else{
                $surname = test_input($_POST["surname"]);
                if (!preg_match("/^[a-zA-Z-' ]*$/",$surname)) {
                  $surnameError = "Only letters and white space allowed";
                }
                $newUser->set_surname($surname);

            }

            if (empty($_POST["dni"])||$_POST["dni"]==" ") {
                $dniError= "You must indicate a dni";
            }else{
                $dni = test_input($_POST["dni"]);
                if (!preg_match('/^[0-9]{7,8}[A-Z]/', $dni)) {
                  $dniError = "Only letters and white space allowed";
                }
                $newUser->set_dni($dni);

            }
            if (empty($_POST["dni"])||$_POST["dni"]==" "&&empty($_POST["surname"])||$_POST["surname"]==" "&&empty($_POST["age"])||$_POST["age"]==0&&empty($_POST["name"])||$_POST["name"]==" ") {
                $dniError= "Non se puido engadir o usuario";
            }else{
                $numberOfRows=$oper->addStudent($newUser);
                if($numberOfRows==1) {
                    $added= "<br>New guest added to database";
                   
                }
            }    
        }  
    }
    $name=$surname=$dni="";
    $age=0; 

    
?>
    <br><br><br>
    <fieldset>
        <legend>Add a new student</legend>
        <table>
            <tr>
                <td><label for="name">Name: </label></td>
                <td><input type="text" name="name" id="1"value=""></td>
                <td><label for="age">Age: </label></td>
                <td><input type="text" name="age" id="3"></td>
            </tr>
            <tr>
                <td><label for="name">Surname: </label></td>
                <td><input type="text" name="surname"  id="2" ></td>
                <td><label for="dni">DNI: </label></td>
                <td><input type="text" name="dni" id="4" ></td>
            </tr>
            <tr>
            <td colspan=3 style="color:red;">
                    <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        if (isset($_REQUEST["add"])) {
                    if ($errorNome!=="") {
                        echo "*".$errorNome;
                        $errorNome=""; 
                    }if($surnameError!==""){
                        echo"<br>*".$surnameError;
                        $surnameError="";
                    }if($ageError!=""){
                        echo "<br>*".$ageError;
                        $ageError="";
                    }if($dniError!=""){
                        echo"<br>*".$dniError;
                        $dniError="";
                    }
                    else{
                        echo $added;
                        $name=$age=$surname=$dni="";
                                        
                    }
                }
            }
                    ?>
                </td>
            </tr>
            <tr>
                
                <td> <input  type="submit" name="add" value="Enviar datos"><br></td>
            </tr>
        </table>
    </fieldset>
    </form>

    <style>
    fieldset {
        width: 300px;
    }
    </style>
</body>

</html>