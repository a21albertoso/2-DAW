<?php
class BasketLeague{
    private  $id;
    private  $teamName;
    private  $teamStadium;
    private $teamColorKit;

    function get_id(){
        return $this->id;
    }
    function set_id($id){
        $this->id=$id;
    }
    function get_teamName(){
        return $this->teamName;
    }
    function set_teamName($teamName){
        $this->teamName=$teamName;
    }
    function get_teamStadium(){
        return $this->teamStadium;
    }
    function set_teamStadium($teamStadium){
        $this->teamStadium=$teamStadium;
    }
    function get_teamColorKit(){
        return $this->teamColorKit;
    }
    function set_teamColorKit($teamColorKit){
        $this->teamColorKit=$teamColorKit;
    }

    
    function __toString(){
        $cadea="<tr>
                  <td> $this->teamName</td>
                  <td> $this->teamStadium</td>
                  <td> $this->teamColorKit</td>
        ";
        return $cadea;
    }
}

class Operations {
    private $conn;
    function __construct(){
        $this->openConnection();
    }
    function openConnection(){
        $servername = "db";
        $username = "manage";
        $password = "test";
        $dbName = "project";
        $this->conn = new PDO("mysql:host=$servername;dbname=$dbName", $username, $password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);   
    }
    function closeConnection(){
        $this->conn=null;
    }
    function addTeam($league){
        $stmt = $this->conn->prepare("insert into basketLeague (teamName, teamStadium ,teamColorKit) VALUES (?, ?, ?)");
        $teamName=$league->get_teamName();
        $teamStadium=$league->get_teamStadium();
        $teamColorKit=$league->get_teamColorKit();
        $stmt->execute([$teamName,$teamStadium,$teamColorKit]);
        $numberOfModifiedRows=$stmt->rowCount();
        return $numberOfModifiedRows;
    }



    function selectAllTeams() { 
        $statement="select id, teamName , teamStadium ,teamColorKit from basketLeague";
        $consulta=$this->conn->prepare($statement);
        $consulta->execute();
        $allTeams=array();

        while ($team=$consulta->fetchObject('basketleague')) {
            $allTeams[]=$team;
        }
        
        return $allTeams;
    }
    function addTeamPlayers($id,$team){
        $stmt = $this->conn->prepare("insert into teams (name,position,age,idTeam) VALUES (?,?,?,?)");
        $name=$team->get_name();
        $position=$team->get_position();
        $age=$team->get_age();
        $idTeam=$id;
        $stmt->execute([$name,$position,$age,$idTeam]);
        $numberOfModifiedRows=$stmt->rowCount();
        return $numberOfModifiedRows;
    }
    function selectAllPlayers($id) { 
        $statement="select *
        FROM teams
        WHERE  teams.idTeam = ? ";
        $consulta=$this->conn->prepare($statement);
        $consulta->execute([$id]);
        $allPlayers=array();

        while ($team=$consulta->fetchObject('BasketTeam')) {
            $allPlayers[]=$team;
        }
        
        return $allPlayers;
    }

    /*
    function deleteUser($delDNI){
        $delete=$this->conn->prepare("delete from users where id='$delDNI'");
        $delete->execute([$delDNI]);
        $numberOfModifiedRows=$delete->rowCount();
        return $numberOfModifiedRows;
    }*/
}

class BasketTeam extends BasketLeague{
    private  $id;
    private  $position;
    private  $name;
    private  $age;
    private  $idTeam;



    function set_id($id){
        $this->id=$id;
    }
    function get_id(){
        return $this->id;
    }
    function set_idTeam($idTeam){
        $this->idTeam=$idTeam;
    }
    function get_idTeam(){
        return $this->idTeam;
    }

    function get_name(){
        return $this->name;
    }
    function set_name($name){
        $this->name=$name;
    }

    function get_position(){
        return $this->position;
    }
    function set_position($position){
        $this->position=$position;
    }

    function get_age(){
        return $this->age;
    }
    function set_age($age){
        $this->age=$age;
    }

    





}


?>
