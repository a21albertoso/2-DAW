<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <form method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">
    <?php

    require "operations.php";
    try {
        $oper = new Operations();
    } catch (PDOException $erro) {
        echo "Connection Failed: ". $erro->getMessage();
    }
    
    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    
    $teamName=$_GET["name"];
    $id= $_GET["id"];
    $name=$position="";
    $age=$idTeam=0;
    try {
    } catch (PDOException $th) {
        $created = "The username and/or the email are already taken ";
    }



    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        if (isset($_REQUEST["addPlayer"])) {
            $newPlayer=new BasketTeam();

            //Set name
            if (empty($_POST["name"])||$_POST["name"]==" ") {
                $nameErr="You must indicate a the name of your team stadium.";
            }else{
                $name = test_input($_POST["name"]);
                $newPlayer->set_name($name);
            }           
            //Set tposition
            if (empty($_POST["position"])||$_POST["position"]==" ") {
                $positionErr="You must indicate a the name of your team stadium.";
            }else{
                $position = test_input($_POST["position"]);
                $newPlayer->set_position($position);
            }
            //Set age 
                $age = $_POST["age"];
                $newPlayer->set_age($age);
            //Set idTeam
                $idTeam=$id;
                $newPlayer->set_idTeam($idTeam);
                $numberOfRows=$oper->addTeamPlayers($idTeam,$newPlayer);
        }
    }

    ?>
    <a href="appMenu.php"> <img src="img/logo-kings-league.svg" class="image" alt="kings league" link="appMenu.php"></a>
   
            <table>
            <th colspan="4"><h3><?php echo $teamName ?> Squad</h3></th>
            <tr class="row">
                <td>Player Name</td>
                <td>Player Position</td>
                <td>Age</td>
                <td></td>
            </tr>
            
                
                <?php 
                $all= $oper->selectAllPlayers($id);
              foreach( $all as $team ){
                echo
                "<tr>
                  <td>". $team->get_name()."</td>
                  <td> ". $team->get_position()."</td>
                  <td> ". $team->get_age()."</td>
                  </tr>
        ";
               }    
                ?>
            </tr>
            <tr>
                <td><input type="text" name="name" value=></td>
                <td><input type="text" name="position" id=""></td>
                <td><input type="number" name="age" id=""></td>
                <td><input type="submit" value="Add" name="addPlayer"></td>
            </tr>
            
        </table>
    </form>

</body>

</html>