<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <form method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">
        <?php

    require "operations.php";
    try {
        $oper = new Operations();

    } catch (PDOException $erro) {
        echo "Connection Failed: ". $erro->getMessage();
    }
    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    $teamColorKit=$teamColorKitErr=$teamName=$teamNameErr=$teamStadium=$teamStadiumErr="";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            if (isset($_REQUEST["addTeam"])) {
                $newLeague=new BasketLeague();
                //Set the name of the Team
                if (empty($_POST["teamName"])||$_POST["teamName"]==" ") {
                    $teamNameErr= "You must indicate a the name of your team.";
                }else{
                    $teamName = test_input($_POST["teamName"]);
                    $newLeague->set_teamName($teamName);
                }
                //Set the stadium of the team
                if (empty($_POST["teamStadium"])||$_POST["teamStadium"]==" ") {
                    $teamStadiumErr= "You must indicate a the name of your team stadium.";
                }else{
                    $teamStadium = test_input($_POST["teamStadium"]);
                    $newLeague->set_teamStadium($teamStadium);
                }
                //Set the color of your team's kit
                if (empty($_POST["teamColorKit"])||$_POST["teamColorKit"]==" ") {
                    $teamColorKitErr= "You must indicate a the name of your team.";
                }else{
                    $teamColorKit = test_input($_POST["teamColorKit"]);
                    $newLeague->set_teamColorKit($teamColorKit);
                }
                $numberOfRows=$oper->addTeam($newLeague);
            }
        }
    ?>
        <a href="appMenu.php"> <img src="img/logo-kings-league.svg" class="image" alt="kings league"
                link="appMenu.php"></a>
        <table>
            <tr>
                <th>Team Name</th>
                <th>Team Stadium</th>
                <th>Team Kit Colors</th>
                <td></td>
            </tr>


            <?php 
              $all= $oper->selectAllTeams();
              foreach( $all as $team ){
                 echo " 
                 $team
                    <td><a href=teams.php?name=".$team->get_teamName() ."&id=".$team->get_id() ." </a>Modify team</a></td>
                 </tr>";
         }        
                ?>
            </tr>
            <tr>
                <td><input type="text" name="teamName" value=></td>
                <td><input type="text" name="teamStadium" id=""></td>
                <td><input type="text" name="teamColorKit" id=""></td>
                <td><input type="submit" value="Add" name="addTeam"></td>
            </tr>
        </table>

    </form>

</body>

</html>