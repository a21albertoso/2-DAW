<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<form  method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">



<?php
include_once 'database.php';


try {
    $oper = new Operations();
}catch (PDOException $erro) {
    echo "Connection failed:" . $erro->getMessage();
}
/*try {
$all = $oper->selectAllMessages();
foreach( $all as $user ){
    echo"<br> Novo usuario: $user";
    --echo "<br> <a href="
}
}*/
catch(Exception $erro){
    echo "Erro: ".$erro->getMessage();
}
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$messageText=$errorMessageText="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
if (isset($_REQUEST["addmessage"])){
    $newMessage=new messages();
    if (empty($_POST["message"]||$_POST["message"] == "")){
        $errorMessageText="*The note cant be blank";
        echo $errorMessageText;
    }else{
        $messageText = test_input($_POST['message']);
        $newMessage->set_messageText($messageText);

    }
}
}

?>

<br>
<textarea name="message" id="" cols="50" rows="30"></textarea>



<input  type="submit" name="addmessage" value="Save">

</form>

<style>

body{
    display: flex;
    justify-content: center;
}

</style>

</body>
</html>