<?php

session_start();
$_SESSION = array();
setcookie(session_name(), 123, time(), - 1000);
header("Location: login.php ");

?>