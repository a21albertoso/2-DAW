<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>USERS:</h1>

    <form method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">

    <?php
//including and creating the connection to database
    require "database.php";

    try {
        $oper = new Operations();

    } catch (PDOException $erro) {
        echo "Connection Failed: ". $erro->getMessage();
    }
    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    //initializating the variables.
    $user=$password=$userErr=$passwordErr=$cadea=$cadea2="";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_REQUEST["addUser"])){
        $newUser=new users();
        if (empty($_POST["username"]||$_POST["username"]==" ")){
            $userErr = "You need to add a name for the account";
        }else{
            $user = test_input($_POST["username"]);
            $newUser->setUsername($user);
        }
        if (empty($_POST["password"]||$_POST["password"]==" ")){
            $passwordErr = "You need to add a pass for the account";
        }else{
            $password = test_input($_POST["password"]);
            $newUser->setPassword($password);
        }
        if ($user&&$password!=="") {
            $numberOfRows=$oper->addUser($newUser);
        }else{
            echo $userErr ."<br>";
            echo $passwordErr."<br>";
        }
        
    }
}
?>

<table>

<tr>
    <th>User:</th>
</tr>
<?php
if ($userErr|| $passwordErr =="") {
   
}
$all = $oper->selectAllUsers();
    foreach($all as $message){//str_replace for chage the password to asterisks.
            $cadea2 =str_replace($message->getPassword(), "*********",$message->getPassword());
            echo
            "<tr>
            <td>" . $message->getID() . "</td>
            <td>" . $message->getUsername() . "</td>
            <td>" . $cadea2 . "</td>
            <td><a href=notes.php?id=".$message->getID().">View notes</a></td>";
            }
    
?>
</tr>

<input type="text" name="username" value="">
<input type="text" name="password" value="">
<input type="submit" value="Add" name="addUser">


</table>

<style>

table{
    background-color: lightgray;
    border: 1px solid grey;
    border-radius: 15px;
    margin-top: 5px;
}

input{
    background-color: DAF402;
    color: black;
}

a{
    background-color: black;
    color:white;
    text-decoration: none;
    border: 2px solid grey;
}

a:hover{
    background-color: white;
    color:black;
    text-decoration: none;
    border: 2px solid black;
}

body{
    display: flex;
    align-items: center;
    flex-direction: column;
    background-color: BDB70B;
}

td{
    width: 100px;
}

h1{
    background-color: black;
    color: white;
    width: 100%;
    top:0;
    display: flex;
    justify-content: center;
}

</style>

</form>
</body>
</html>