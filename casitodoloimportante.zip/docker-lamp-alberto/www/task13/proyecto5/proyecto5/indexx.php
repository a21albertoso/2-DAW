<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<h1>NOTE:</h1>

<form  method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">



<?php
include_once 'database.php';
//including and creating the connection to database

try {
    $oper = new Operations();
}catch (PDOException $erro) {
    echo "Connection failed:" . $erro->getMessage();
}

catch(Exception $erro){
    echo "Erro: ".$erro->getMessage();
}
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$ID = $_GET["id"];
$userID = $_GET["userID"];
$message=$errorMessageText="";
$messageID=0;

//using post methods

if ($_SERVER["REQUEST_METHOD"] == "POST") {
if (isset($_REQUEST["addmessage"])){
    $newMessage=new messages();
    if (empty($_POST["message"])||$_POST["message"]==" "){
        $errorMessageText="The note cant be blank";
    }else{
        $messageText = test_input($_POST["message"]);
        $newMessage->set_messageText($messageText);
    }
    $numberOfRows=$oper->modifyMessage($messageText,$ID);
}
if (isset($_REQUEST["getMessage"])){
$message = $oper->getMessage($ID);


}}


//creating the fields
        
?>

<br>
<textarea name="message" id="" cols="50" rows="30"><?php echo $message;/*for print the message over the textarea saved in the variable*/ ?></textarea><br>

<input  type="submit" name="addmessage" value="Save">

<input type="submit" name="getMessage" value="View">

<?php
echo "<a href="."notes.php?id=".$userID.">back</a>";
?>


</form>

<style>


body{
    display: flex;
    align-items: center;
    flex-direction: column;
    background-color: BDB70B;
}

input{
    background-color: black;
    color:white;
    text-decoration: none;
    border: 2px solid grey;
}

input:hover{
    background-color: white;
    color:black;
    text-decoration: none;
    border: 2px solid black;
}

a{
    background-color: black;
    color:white;
    text-decoration: none;
    border: 2px solid grey;
}

a:hover{
    background-color: white;
    color:black;
    text-decoration: none;
    border: 2px solid black;
}

textarea{
    background-color: DAF402;
}

h1{
    background-color: black;
    color: white;
    width: 100%;
    top:0;
    display: flex;
    justify-content: center;
}

</style>

</body>
</html>