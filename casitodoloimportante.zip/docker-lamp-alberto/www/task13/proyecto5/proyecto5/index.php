<?php

session_start();
require "DBOperations.php";
if(isset($_SESSION['username'])){
    header("Location: login.php?redirect=true");
}


$cookieName="example1";
$example1 = new Example();
$example1->setcode(1);
$example1->setdescription("U iniciated session with session1");
$cookieVal = $example1;
setcookie($cookieName, $cookieVal, time() + (86400*15), "/");

$example2 = new Example();
$example2->setcode(2);
$example2-setdescription("U iniciated session with session2");
$session_name="example2";
$_SESSION[$session_name] = $example2;


?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<h1>WELCOME</h1>
<?php echo "You are in ". $_SESSION['username'] ."<br>";

if(isset($_COOKIE[$cookieName])){
    echo $cookieName."is set<br>";
}else{
    echo $cookieName."is not set<br>";
}
?>

<a href="logout.php">Left</a>
<a href="next.php">Next</a>

</body>
</html>