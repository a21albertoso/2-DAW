<?php

class DBOperations{
    private $conn;
    function __construct(){
        $this->openConnection();
    }

    function openConnection(){
        $servername = "db";
        $username = "dbname";
        $password = "test";
        $dbname = "dbnamee";
        $this->conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    function closeConnection(){
        $this->conn = null;
    }
}
    class Login{
        private $username;
        private $password;

        function __toString(){
            $var = "User: ". $this->username ."
            <br>Password: ". $this->password;
        }
    }

    class Example{
        private $code;
        private $description;

        function getCode(){
            $this->code;
        }

        function setCode($code){
            $this->code = $code;
        }

        function getDescription(){
            $this->description;
        }

        function setDescription($description){
            $this->description = $description;
        }
    }


?>