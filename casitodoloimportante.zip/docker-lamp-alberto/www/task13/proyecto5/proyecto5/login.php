<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method = "POST">
<?php

if($_POST){
    session_start();

    require "DBOperations.php";
    $username = $_POST['username'];
    $password = $_POST['password'];
    $select = $conn->prepare("select * from Login where user=? and password=?");
    $select->execute([$username,$password]);
    $username = $select->fetch(PDO::FETCH_OBJ);
    if($select->rowCount() === 1){
        $_SESSION['username'] = $username->username;
        header("Location: index.php");
    }else{
        echo "incorrect login";
    }

}
?>

    <?php
    if(isset($_GET["redirect"])){
        echo "<h1> introduce login to continue</h1>";
    }if(isset($Err) && $Err === true){
        echo "check your login or your password";
    }
    ?>

    <h1>Login:</h1>
    <label for="username">User</label>
    <input value="<?php if(isset($username));?>" name="username" type="text"><br><br>
    <label for="password">Password</label>
    <input name="password" type="password"><br><br>
    <input type="submit" name="send" value="login">
</form>
</body>
</html>