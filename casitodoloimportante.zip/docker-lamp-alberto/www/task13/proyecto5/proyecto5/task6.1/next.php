<?php require "index.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>next</title>
</head>
<body>
    <h1>Next</h1>

    <?php 
        echo "The value of the cookie is: " . $_COOKIE[$cookie_name];
       
        echo "<br>The value of the session is: ". $_SESSION[$session_name];
    ?>
</body>
</html>