<?php 
        if($_POST){
            session_start(); 

        require "DBOperations.php";
        $user= $_POST['user'];
        $pass=$_POST['password'];
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $select = $conn->prepare("select * from login where user=? and password= ?");
        $select->execute([$user, $pass]);
        $user = $select->fetch(PDO::FETCH_OBJ);
        if($select->rowCount()== 1){
            $_SESSION['user']= $user->user;
            header("Location: index.php");
        }else{
            echo "Incorrect user or password";
        }

     }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php 
        if(isset($_GET["redirect"])){
			echo "<p>Please introduce login to continue </p>";
		}?>
		<?php if(isset($err) and $err == true){
			echo "<p> Please check user and password </p>";
		}?>
        <h1>Login</h1>
		<form action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method = "POST">
			<label for="user">  User</label>
			<input value = "<?php if(isset($user)) echo $user;?>"
			id = "user" name = "user" type = "text"><br><br>
            <label for="password">Password</label>				
			<input id = "password" name = "password" type = "password">	<br><br>					
			<input type = "submit" name="sendLogin" value="login">
		</form>

</body>
</html>