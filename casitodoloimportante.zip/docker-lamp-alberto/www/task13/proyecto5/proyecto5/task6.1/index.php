<?php
    session_start();
    require "DBOperations.php";
    if(!isset($_SESSION['user'])){
        header("Location: login.php?redirect=true");
    }

?>
<?php

//COOKIE
$cookie_name = "example1";
$ex1 = new Example();
$ex1->setcode(1);
$ex1->setdescription("Description of example number 1");
$cookie_value = $ex1;
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

//SESSION
$ex2 = new Example();
$ex2->setcode(2);
$ex2->setdescription("Description of example number 2");
$session_name="example2";
$_SESSION[$session_name]=$ex2;

?>
<html>
<body>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>principal</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Welcome!!</h1>
    <?php echo "You are in ".$_SESSION['user']. "!!";?><br>

    <?php 
    
    if(!isset($_COOKIE[$cookie_name])) {
         echo "Cookie named '" . $cookie_name . "' is not set!";
    } else {
         echo "Cookie '" . $cookie_name . "' is set!<br>";
         
    }

    if(!isset($_SESSION[$session_name])) {
        echo "Session named '" . $session_name . "' is not set!";
   } else {
        echo "Session '" . $session_name . "' is set!<br>";
        
   }
    ?>
    


	<br><a href = "logout.php"> Salir </a>
	<a href = "next.php"> Next </a>

    
</body>
</html>