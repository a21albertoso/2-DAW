<?php

$servername = "db";
$username = "root";
$password = "test";
$dbName = "dbname";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbName", $username, $password);
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}

    Class Login{

        private $user;
        private $password;


        function __toString(){
            $cadea = "<br> User: $this->user <br>";
            $cadea.="<br> Password: $this->password <br>";
            return $cadea;
        }
    }

    Class Example{

        private $code;
        private $description;

        function __toString(){
            $cadea = "<br> Code: $this->code";
            $cadea.="<br> Description: $this->description <br>";
            return $cadea;
        }

        function setcode($code){
            $this->code = $code;
        }

        function setdescription($description){
            $this->description = $description;
        }

        function getcode(){
            return $this->code;
        }

        function getdescription(){
            return $this->description;
        }
    }
?>