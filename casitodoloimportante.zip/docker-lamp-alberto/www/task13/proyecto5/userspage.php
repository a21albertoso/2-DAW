<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>

</style>
<body>
    <h1>Register:</h1>
    <form  method="POST" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">
    <?php

    require "database.php";
    try{
        $oper = new Operations();

        }catch (PDOException $error){
            echo "Connection Failed:". $error->getMessage();
        }
        try{
            
        }
    
</body>
</html>