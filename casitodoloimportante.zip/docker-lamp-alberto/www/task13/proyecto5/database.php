<?php

class users{
    private $userID;
    private $name;
    private $password;


    function get_userID(){
        return $this->userID;
    }

    function set_userID($userID){
        $this->userID=$userID;
    }

    function get_username(){
        return $this->name;
    }

    function set_username($name){
        $this->name=$name;
    }

    function get_password(){
        return $this->pass;
    }

    function set_password($pass){
        $this->pass=$pass;
    }

    function __toString(){
        $cadea = "<br>ID: $this->userID <br> Username: $this->name <br> Password: $this->pass";
    return $cadea;
    }

}
class messages extends users{
    private $messageID;
    private $messageText;
    private users $userID;

    function get_messageID(){
        return $this->messageID;
    }

    function set_messageID($messageID){
        $this->messageID=$messageID;
    }

    function get_messageText(){
        return $this->messageText;
    }

    function set_messageText($messageText){
        $this->messageText=$messageText;
    }

    function __toString(){
       return parent::__toString(). "<br> MessageID: " . $messageID . "<br>Message: " . $messageText;

    }

}

class Operations{
    private $conn;
    function __construct(){
        $this->openConnection();
    }
    function openConnection(){
        $servername = "db";
        $username = "dbuser";
        $password = "test";
        $dbname = "dbproject";
        $this->conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        function closeConnection(){
            $this->conn=null;
        }
        function addUser($user){
            $stmt = $this->conn->prepare("insert into users (username, password) VALUES (?, ?)");
            $name = $user->get_username();
            $pass = $user->get_password();
            $stmt->execute([$name,$pass]);
            $numberOfModifiedRows=$stmt->rowCount();
            return $numberOfModifiedRows;
        }

        function modifyUser($newUser,$userID){
            $name=$newUser->get_username();
            $pass=$newUser->get_password();
            $stmt = $this->conn->prepare("update users set username='$name', password='$pass'");
            $stmt->execute([$userID,$name,$pass]);
            $numberOfModifiedRows=$stmt->rowCount();
            return $numberOfModifiedRows;
        }

        function addMessage($userID,$message){
            $stmt = $this->conn->prepare("insert into messages (messageText, userofID) VALUES (?, ?)");
            $messageText = $message->get_messageText();
            $userofID = $userID;
            $stmt->execute([$messageText, $userofID]);
            $numberOfModifiedRows=$stmt->rowCount();
            return $numberOfModifiedRows;
        }

        function modifyMessage($newMessage, $messageID){
            $messageText=$newMessage->get_messageText();
            $stmt = $this->conn->prepare("update messages set messageText='$messageText', userofID='$userofID'");
            $stmt->execute([$messageID,$messageText,$userofID]);
        }

        function getMessage($messageID){
            $sqlString="select messageID, messageText, userID from where messageID=?";
            $consult=$this->conn->prepare($sqlString);
            $consult->execute([$messageID]);
            $messages=$consult->fetchObject('messages');
            return $messages;
        }

        function selectAllMessages(){
            $statement="select messageID, messageText, userID from messages";
            $consult=$this->conn->prepare($statement);
            $consult->execute();
            $allmessages=array();

            while ($messages=$consult->fetchObject('messages')) {
                $allMessages[]=$messages;
            }
            return $allMessages;
        }
}



?>