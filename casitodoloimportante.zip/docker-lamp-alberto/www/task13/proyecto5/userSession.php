<?php

class userSession{

public function __construct(){
    session_start();
}

public function setCurrentUser($name){
    $_SESSION['username'] = $name;
}

public function getCurrentUser(){
    return $_SESSION['username'];
}

public function closeSession(){
    session_unset();
    session_destroy();
}


}
?>