<?php

class Person{
    private $name;
    private $age;
    private $id;

    public function __construct($name="",$age=0,$id=0){
        $this->name=$name;
        $this->age=$age;
        $this->id=$id;
    }

    public function __toString(){
        echo "Name: " . $this->name . "<br> Age: " . $this->age . "<br> id: " . $this->$id;
    }
}

class Information{
    public function printProperties();
}

class Vehicle implements Information{
    private $brand;
    private $model;
    private Person $owner;

    public function __construct($brand="",$model="",$owner=""){
        $this->brand=$brand;
        $this->model=$model;
        $this->owner=$owner;
    }
}



class Maths{

    public function division($num1,$num2){

        if($num2 == 0){
            throw new Exception("The second interger is 0");
        }

        $division=$num1/$num2;
        $intconversion=intval($division);
        $remainder=$num1%$num2;

    }

}




?>