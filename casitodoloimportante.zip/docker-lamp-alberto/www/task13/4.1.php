<?php
class Calculator {
  // Properties
  public int $num1;
  public int $num2;

  // Methods
  function set_num1($num1) {
    $this->num1 = $num1;
  }
  function get_num1() {
    return $this->num1;
  }
  function set_num2($num2) {
    $this->num2 = $num2;
  }
  function get_num2() {
    return $this->num2;
  }

  function __construct($num1=0, $num2=0){
    $this->num1 = $num1;
    $this->num2 = $num2;
  }

  function multiply(){
    return $this->num1 * $this->num2;
  }

  function plus(){
    return $this->num1 + $this->num2;
  }

  function __toString(){
    return "the number is " . $this->num1 . " and " . $this->num2;
  }

}

$firstCalcule = new Calculator();
$firstCalcule->set_num1(3);
$firstCalcule->set_num2(5);
echo "nº1: " . $firstCalcule->get_num1();
echo "<br>";
echo "nº2: " . $firstCalcule->get_num2();
echo "<br>";

$secondCalcule = new Calculator(3,7);
echo $secondCalcule->__toString();
echo "<br> Multiply: " . $secondCalcule -> multiply();
echo "<br> Add: " . $secondCalcule -> plus();


?>
