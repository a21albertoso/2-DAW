<?php

require 'flight/Flight.php';

Flight::register('db','PDO',array('mysql:host=db;dbname=api','root','test'));

//Lee y muestra los datos.
Flight::route('GET /alumnos', function(){
    $sentencia = Flight::db()->prepare("SELECT * FROM alumnos ");
    $sentencia->execute();
    $datos = $sentencia->fetchAll();
    Flight::json($datos);
});

//Recepciona los datos por método POST.
Flight::route('POST /alumnos', function(){
    $nombre = (Flight::request()->data->nombre);
    $apellido = (Flight::request()->data->apellido);

    $sql = "INSERT INTO alumnos (nombre,apellido) VALUES(?,?)";
    $sentencia = Flight::db()->prepare($sql);

    $sentencia->bindParam(1,$nombre);
    $sentencia->bindParam(2,$apellido);
    $sentencia->execute();
    Flight::jsonp(["Alumno agregado"]);

});

//borrar os usuarios da base de datos mediante a api.
Flight::route('DELETE /alumnos', function() {
    $id=(Flight::request()->data->id);

    $sql="DELETE FROM alumnos WHERE id=?";
    $sentencia= Flight::db()->prepare($sql);
    $sentencia->bindParam(1,$id);
    $sentencia->execute();

    Flight::jsonp(["Alumno borrado"]);
});

//actualizar os datos da base mediante a api.
Flight::route('PUT /alumnos', function() {
    $id=(Flight::request()->data->id);
    $nombre=(Flight::request()->data->nombre);
    $apellido=(Flight::request()->data->apellido);

    $sql="UPDATE alumnos SET nombre=? ,apellido=? WHERE id=?";

    $sentencia= Flight::db()->prepare($sql);

    $sentencia->bindParam(1,$nombre);
    $sentencia->bindParam(2,$apellido);
    $sentencia->bindParam(3,$id);

    $sentencia->execute();
    Flight::jsonp(["Alumno modificado"]);

});

Flight::start();