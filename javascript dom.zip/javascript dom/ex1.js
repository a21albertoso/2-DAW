const text = document.getElementsByTagName("div")[0];
console.log(text);
const text2 = document.getElementsByTagName("ul")[0];
console.log(text2);
const text3 = document.getElementsByTagName("li")[1];
console.log(text3);