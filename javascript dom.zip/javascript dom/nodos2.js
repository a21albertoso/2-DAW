const text = document.getElementsByTagName("a").length;
console.log(text);